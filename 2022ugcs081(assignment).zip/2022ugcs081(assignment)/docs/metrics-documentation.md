# Metrics Documentation for WordPress on Kubernetes

## Table of Contents
1. [Container Metrics](#container-metrics)
2. [WordPress Application Metrics](#wordpress-application-metrics)
3. [Nginx Metrics](#nginx-metrics)
4. [MySQL Metrics](#mysql-metrics)
5. [Kubernetes Cluster Metrics](#kubernetes-cluster-metrics)
6. [Custom Application Metrics](#custom-application-metrics)
7. [Alerting Rules](#alerting-rules)
8. [Dashboard URLs](#dashboard-urls)

## Container Metrics

### CPU Metrics
| Metric Name | Description | Unit | Labels |
|------------|-------------|------|--------|
| `container_cpu_usage_seconds_total` | Cumulative CPU usage | seconds | pod, namespace, container |
| `container_cpu_system_seconds_total` | System CPU usage | seconds | pod, namespace, container |
| `container_cpu_user_seconds_total` | User CPU usage | seconds | pod, namespace, container |
| `container_cpu_cfs_throttled_periods_total` | Number of throttled periods | count | pod, namespace, container |

**Query Examples:**
```promql
# CPU usage percentage for WordPress pods
100 * (rate(container_cpu_usage_seconds_total{pod=~"wordpress-.*"}[5m]))

# Average CPU usage across all WordPress pods
avg(rate(container_cpu_usage_seconds_total{pod=~"wordpress-.*"}[5m])) by (pod)
```

### Memory Metrics
| Metric Name | Description | Unit | Labels |
|------------|-------------|------|--------|
| `container_memory_usage_bytes` | Current memory usage | bytes | pod, namespace, container |
| `container_memory_working_set_bytes` | Working set memory | bytes | pod, namespace, container |
| `container_memory_cache` | Page cache memory | bytes | pod, namespace, container |
| `container_memory_rss` | RSS memory | bytes | pod, namespace, container |

**Query Examples:**
```promql
# Memory usage in MB for WordPress pods
container_memory_working_set_bytes{pod=~"wordpress-.*"} / 1024 / 1024

# Memory usage percentage
100 * (container_memory_working_set_bytes{pod=~"wordpress-.*"} / container_spec_memory_limit_bytes{pod=~"wordpress-.*"})
```

### Network Metrics
| Metric Name | Description | Unit | Labels |
|------------|-------------|------|--------|
| `container_network_receive_bytes_total` | Network bytes received | bytes | pod, namespace, interface |
| `container_network_transmit_bytes_total` | Network bytes transmitted | bytes | pod, namespace, interface |
| `container_network_receive_packets_total` | Packets received | count | pod, namespace, interface |
| `container_network_transmit_packets_total` | Packets transmitted | count | pod, namespace, interface |

## WordPress Application Metrics

### PHP-FPM Metrics
| Metric Name | Description | Unit | Labels |
|------------|-------------|------|--------|
| `phpfpm_accepted_connections` | Accepted connections | count | pool |
| `phpfpm_active_processes` | Active processes | gauge | pool |
| `phpfpm_idle_processes` | Idle processes | gauge | pool |
| `phpfpm_max_active_processes` | Max active processes | gauge | pool |
| `phpfpm_slow_requests` | Slow requests | counter | pool |
| `phpfpm_listen_queue` | Listen queue size | gauge | pool |

### WordPress-Specific Metrics
| Metric Name | Description | Unit | Labels |
|------------|-------------|------|--------|
| `wordpress_posts_total` | Total posts | gauge | type |
| `wordpress_users_total` | Total users | gauge | role |
| `wordpress_comments_total` | Total comments | gauge | status |
| `wordpress_plugin_updates` | Available plugin updates | gauge | - |
| `wordpress_cache_hits` | Cache hits | counter | cache_type |
| `wordpress_cache_misses` | Cache misses | counter | cache_type |

## Nginx Metrics

### Request Metrics
| Metric Name | Description | Unit | Labels |
|------------|-------------|------|--------|
| `nginx_http_requests_total` | Total HTTP requests | counter | host, status, method |
| `nginx_http_request_duration_seconds` | Request duration | histogram | host, method |
| `nginx_connections_current` | Current connections | gauge | state |
| `nginx_connections_accepted` | Accepted connections | counter | - |
| `nginx_connections_handled` | Handled connections | counter | - |

### Error Metrics
| Metric Name | Description | Unit | Labels |
|------------|-------------|------|--------|
| `nginx_http_5xx_errors_total` | Total 5xx errors | counter | host |
| `nginx_http_4xx_errors_total` | Total 4xx errors | counter | host |
| `nginx_upstream_errors_total` | Upstream errors | counter | upstream |
| `nginx_connection_errors_total` | Connection errors | counter | type |

**Query Examples:**
```promql
# Request rate per second
sum(rate(nginx_http_requests_total[5m])) by (status)

# 5xx error rate
sum(rate(nginx_http_requests_total{status=~"5.."}[5m]))

# Average request duration
histogram_quantile(0.95, sum(rate(nginx_http_request_duration_seconds_bucket[5m])) by (le))

# Requests per method
sum(rate(nginx_http_requests_total[5m])) by (method)
```

## MySQL Metrics

### Connection Metrics
| Metric Name | Description | Unit | Labels |
|------------|-------------|------|--------|
| `mysql_global_status_threads_connected` | Connected threads | gauge | - |
| `mysql_global_status_max_used_connections` | Max used connections | gauge | - |
| `mysql_global_status_aborted_connects` | Aborted connections | counter | - |
| `mysql_global_status_connection_errors_total` | Connection errors | counter | error |

### Query Metrics
| Metric Name | Description | Unit | Labels |
|------------|-------------|------|--------|
| `mysql_global_status_queries` | Total queries | counter | - |
| `mysql_global_status_slow_queries` | Slow queries | counter | - |
| `mysql_global_status_questions` | Total questions | counter | - |
| `mysql_global_status_commands_total` | Commands executed | counter | command |

### Performance Metrics
| Metric Name | Description | Unit | Labels |
|------------|-------------|------|--------|
| `mysql_global_status_qcache_hits` | Query cache hits | counter | - |
| `mysql_global_status_qcache_inserts` | Query cache inserts | counter | - |
| `mysql_global_status_qcache_not_cached` | Queries not cached | counter | - |
| `mysql_global_status_innodb_buffer_pool_read_requests` | Buffer pool reads | counter | - |
| `mysql_global_status_innodb_buffer_pool_reads` | Disk reads | counter | - |

**Query Examples:**
```promql
# Query rate
rate(mysql_global_status_queries[5m])

# Slow query rate
rate(mysql_global_status_slow_queries[5m])

# Connection usage percentage
(mysql_global_status_threads_connected / mysql_global_variables_max_connections) * 100

# Cache hit ratio
(mysql_global_status_qcache_hits / (mysql_global_status_qcache_hits + mysql_global_status_qcache_inserts + mysql_global_status_qcache_not_cached)) * 100
```

## Kubernetes Cluster Metrics

### Node Metrics
| Metric Name | Description | Unit | Labels |
|------------|-------------|------|--------|
| `node_cpu_seconds_total` | CPU time | seconds | cpu, mode |
| `node_memory_MemTotal_bytes` | Total memory | bytes | - |
| `node_memory_MemFree_bytes` | Free memory | bytes | - |
| `node_filesystem_size_bytes` | Filesystem size | bytes | device, mountpoint |
| `node_filesystem_avail_bytes` | Available filesystem | bytes | device, mountpoint |

### Pod Metrics
| Metric Name | Description | Unit | Labels |
|------------|-------------|------|--------|
| `kube_pod_status_phase` | Pod phase status | gauge | pod, namespace, phase |
| `kube_pod_container_status_restarts_total` | Container restarts | counter | pod, namespace, container |
| `kube_pod_container_resource_requests` | Resource requests | gauge | pod, namespace, container, resource |
| `kube_pod_container_resource_limits` | Resource limits | gauge | pod, namespace, container, resource |

### Deployment Metrics
| Metric Name | Description | Unit | Labels |
|------------|-------------|------|--------|
| `kube_deployment_status_replicas` | Current replicas | gauge | deployment, namespace |
| `kube_deployment_status_replicas_available` | Available replicas | gauge | deployment, namespace |
| `kube_deployment_status_replicas_unavailable` | Unavailable replicas | gauge | deployment, namespace |
| `kube_deployment_spec_replicas` | Desired replicas | gauge | deployment, namespace |

## Custom Application Metrics

### Business Metrics
| Metric Name | Description | Unit | Labels |
|------------|-------------|------|--------|
| `wordpress_login_attempts_total` | Login attempts | counter | status |
| `wordpress_page_generation_time_seconds` | Page generation time | histogram | page_type |
| `wordpress_api_calls_total` | API calls | counter | endpoint, method |
| `wordpress_file_uploads_total` | File uploads | counter | type |
| `wordpress_search_queries_total` | Search queries | counter | - |

### Performance Metrics
| Metric Name | Description | Unit | Labels |
|------------|-------------|------|--------|
| `wordpress_database_query_time_seconds` | DB query time | histogram | query_type |
| `wordpress_cache_hit_ratio` | Cache hit ratio | gauge | cache_type |
| `wordpress_plugin_execution_time_seconds` | Plugin execution time | histogram | plugin |
| `wordpress_theme_load_time_seconds` | Theme load time | histogram | theme |

## Alerting Rules

### Critical Alerts
| Alert Name | Expression | Duration | Description |
|-----------|------------|----------|-------------|
| `WordPressDown` | `up{job="wordpress"} == 0` | 5m | WordPress instance is down |
| `MySQLDown` | `mysql_up == 0` | 5m | MySQL database is down |
| `High5xxErrors` | `sum(rate(nginx_http_requests_total{status=~"5.."}[5m])) > 0.1` | 5m | High 5xx error rate |
| `DiskSpaceLow` | `(node_filesystem_avail_bytes / node_filesystem_size_bytes) < 0.1` | 10m | Less than 10% disk space |
| `HighMemoryPressure` | `(container_memory_working_set_bytes / container_spec_memory_limit_bytes) > 0.9` | 10m | Memory usage above 90% |

### Warning Alerts
| Alert Name | Expression | Duration | Description |
|-----------|------------|----------|-------------|
| `HighCPUUsage` | `rate(container_cpu_usage_seconds_total[5m]) > 0.8` | 10m | CPU usage above 80% |
| `SlowQueries` | `rate(mysql_global_status_slow_queries[5m]) > 0.05` | 10m | High slow query rate |
| `HighConnectionCount` | `mysql_global_status_threads_connected > 100` | 5m | High MySQL connections |
| `CacheHitRateLow` | `wordpress_cache_hit_ratio < 0.8` | 15m | Cache hit ratio below 80% |
| `PodRestartingFrequently` | `rate(kube_pod_container_status_restarts_total[1h]) > 0` | 0m | Pod restarting frequently |

## Dashboard URLs

### Grafana Dashboards

After deployment, access the following dashboards:

1. **WordPress Application Dashboard**
   - URL: `http://<grafana-url>/d/wordpress-main/wordpress-application-dashboard`
   - Shows: Request rates, error rates, response times, resource usage

2. **Nginx Performance Dashboard**
   - URL: `http://<grafana-url>/d/nginx-perf/nginx-performance`
   - Shows: Connection stats, request distribution, upstream health

3. **MySQL Performance Dashboard**
   - URL: `http://<grafana-url>/d/mysql-perf/mysql-performance`
   - Shows: Query performance, connection pool, cache statistics

4. **Kubernetes Cluster Overview**
   - URL: `http://<grafana-url>/d/k8s-cluster/kubernetes-cluster-overview`
   - Shows: Node health, pod status, resource allocation

5. **Container Metrics Dashboard**
   - URL: `http://<grafana-url>/d/container-metrics/container-metrics`
   - Shows: CPU, memory, network, and disk metrics per container

### Prometheus Queries

Access Prometheus UI for ad-hoc queries:
- URL: `http://<prometheus-url>/graph`

Common queries:
```promql
# Top 5 CPU consuming pods
topk(5, rate(container_cpu_usage_seconds_total[5m])) by (pod)

# Memory usage by namespace
sum(container_memory_working_set_bytes) by (namespace)

# Request latency percentiles
histogram_quantile(0.99, sum(rate(nginx_http_request_duration_seconds_bucket[5m])) by (le))

# Error rate by status code
sum(rate(nginx_http_requests_total{status=~"[4-5].."}[5m])) by (status)
```

## Metric Collection Best Practices

### Scrape Intervals
- Container metrics: 30s
- Application metrics: 30s
- Nginx metrics: 30s
- MySQL metrics: 60s
- Node metrics: 60s

### Retention Policies
- High-resolution data: 7 days
- 5-minute averages: 30 days
- Hourly averages: 90 days
- Daily averages: 1 year

### Performance Optimization
1. Use recording rules for frequently-used queries
2. Implement proper label cardinality limits
3. Use metric relabeling to drop unnecessary labels
4. Configure appropriate scrape timeouts
5. Use federation for multi-cluster setups

## Troubleshooting

### Missing Metrics
1. Check ServiceMonitor is created: `kubectl get servicemonitor -n monitoring`
2. Verify Prometheus targets: Access Prometheus UI → Status → Targets
3. Check pod annotations: `kubectl describe pod <pod-name> -n wordpress`
4. Review Prometheus logs: `kubectl logs -n monitoring prometheus-0`

### High Cardinality Issues
1. Identify high cardinality metrics:
   ```promql
   topk(10, count by (__name__)({__name__=~".+"}))
   ```
2. Review label combinations
3. Implement metric relabeling rules
4. Consider metric aggregation

### Performance Issues
1. Check Prometheus resource usage
2. Review scrape duration: `prometheus_target_scrape_duration_seconds`
3. Optimize PromQL queries
4. Implement recording rules for complex queries

## References

- [Prometheus Documentation](https://prometheus.io/docs/)
- [Grafana Documentation](https://grafana.com/docs/)
- [Kubernetes Metrics](https://kubernetes.io/docs/concepts/cluster-administration/system-metrics/)
- [WordPress Metrics Plugin](https://wordpress.org/plugins/wp-prometheus-metrics/)
